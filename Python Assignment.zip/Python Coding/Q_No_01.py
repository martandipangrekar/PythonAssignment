A = [1, 2, 3, 4, 5, 6]

for x in A:
  x = x**2
  print(x)

print("The sequence has ended")
